<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta content="text/html; charset=utf-8" http-equiv=content-Type>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Car Info | All car Information System</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link href="css/prettyPhoto.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" />	
    
  </head>
  <body>
	<header>	

		

	<section>
		<div class="col-md-4" style='margin:10% 0 0 33%; '>
      <div class="modal-content" style='background-color:black;'>
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         <img src="images/1.jpg" class='img-circle' height='100px' width='100px'style='margin:0 0 0 35%;'/> 
	
        </div>
        <div class="modal-body">
          <form action="" method="Post" role="form">
            <div class="form-group">
              <label for="usrname"><span class="glyphicon glyphicon-user"></span> Username</label>
              <input type="text" class="form-control" id="usrname" name="Uname" placeholder="Enter Name" required='required'> <br>
               <label for="Password"><span class="glyphicon glyphicon-lock"></span> Password</label>
              <input type="password" class="form-control" id="Password" name="Upass" placeholder="Enter Password" required> <br>
               <button type="submit" class="btn  btn-success btn-block" name='submit' ><span class="glyphicon glyphicon-off"></span> Login</button>
               </form>
            </div>
            <div class="form-group">
          
          <p><a href="signup.php" style="color:White">Register</a></p>
        </div>
      </div>
    </div>
  </div> 

	
	
	</section>
	
	
	
	
	</body>
	</html>
	
	
<?php

	if(isset($_POST['submit'])) {
	
		$u=$_POST['Uname'];
		$p=$_POST['Upass'];
		
		$servername='localhost';
		$username='root';
		$password='';
		$dbname='car_info';
	
		$conn = new mysqli($servername, $username, $password, $dbname);
	
		if($conn->connect_error){
			die("Connection Failed : " .$conn->connect_error);
		}

		$q="Select * From users where fname='$u' and password='$p' ";
			$result= $conn->query($q);
			if($result->num_rows > 0){
				$row=$result->fetch_assoc();
				session_start();
				$_SESSION['Uname']=$row['fname'];
				$_SESSION['Upass']=$row['password'];
							
				if($u=='admin'){
					$_SESSION['admin']=$row['fname'];
					$_SESSION['admin']=$row['password'];
					echo "admin";
					
					header('location:dashboard.php');
					
				}
				else{
					header('location:users_dashboard.php');
		
				}	
				
			}
	}		
	
?>


	