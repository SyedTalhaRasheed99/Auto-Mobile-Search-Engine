<!DOCTYPE html>
<html>
<head>
	<title>Admin Dashboard</title>
</head>
<body>
	<h4>Welcome to Admin Dashboard</h4>
</body>
</html>