<?php
include 'connection.php';
$id = $_GET['id'];
// sql to delete a record
$sql = "DELETE FROM cars_model WHERE car_id= $id";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
    header('Location: cars_records.php');
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>