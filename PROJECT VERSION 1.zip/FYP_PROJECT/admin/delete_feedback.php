<?php
include 'connection.php';
$id = $_GET['id'];
// sql to delete a record
$sql = "DELETE FROM feedback WHERE feed_id= $id";

if ($conn->query($sql) === TRUE) {
    echo "Record Deleted successfully";
    header('Location: feedback.php');
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>