<?php
include 'connection.php';
$id = $_GET['id'];
// sql to delete a record
$sql = "DELETE FROM users WHERE user_id= $id";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
    header('Location: all_customer.php');
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>