<?php
/*
Author: Fakhar 

*/
?>
<?php
session_start();
if(!isset($_SESSION["Uname"])){
header("Location:..\index.php");
exit(); }
?>
