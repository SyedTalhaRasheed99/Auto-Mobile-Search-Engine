<?php
include 'connection.php';
$id = $_POST['id'];
$cname=$_POST['car_name'];
$cmodel=$_POST['car_model'];
$man_by=$_POST['man_name']; 
$price=$_POST['price'];
$uploaddir = 'uploads/';

$image = $uploaddir . basename($_FILES['image']['name']);

if (move_uploaded_file($_FILES['image']['tmp_name'], $image)) {
    echo "Image succesfully uploaded.";
} else {
    echo "Image uploading failed.";
}

// sql to delete a record
$sql = "UPDATE cars_model SET car_name='$cname',car_model='$cmodel',man_by='$man_by',price='$price',image='$image' WHERE car_id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
    header('Location: cars_records.php');
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>