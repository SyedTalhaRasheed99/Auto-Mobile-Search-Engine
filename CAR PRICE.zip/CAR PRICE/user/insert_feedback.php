<?php
	include 'connection.php';
	$name=$_POST['name'];
	$gmail=$_POST['gmail'];
	$message=$_POST['messages'];
	echo $message ;
	$sql = "INSERT INTO `feedback`( `name`, `gmail`, `message`) VALUES ('$name','$gmail','$message')";
	if (mysqli_query($conn, $sql)) {
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
	mysqli_close($conn);
?>